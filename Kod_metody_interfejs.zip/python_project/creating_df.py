from PIL import Image
import os
import pandas as pd
import numpy as np
import random

from metrics import find_frame_elements, getPixels


def create_matrix_of_bindings_type(directory):  # funkcja tworząca przejściową macierz dotyczącą typów puzzli
    elements_of_frame, corners, non_frame_elements = find_frame_elements(directory)
    path = directory
    path_el = os.listdir(path)
    matrix_of_bindings_type = [[False] * 5 for i in range(len(path_el))]
    matrix_of_bindings_type[0] = [corners[0], True, False, True,
                                  False]  # Pozycja True oznacza, że na tej pozycji puzzel jest ramką
    matrix_of_bindings_type[1] = [corners[1], True, False, False, True]
    matrix_of_bindings_type[2] = [corners[2], False, True, True, False]
    matrix_of_bindings_type[3] = [corners[3], False, True, False, True]

    k = 4
    for i in range(len(elements_of_frame)):

        for element in elements_of_frame[i]:
            if (i == 0):
                matrix_of_bindings_type[k] = [element, True, False, False, False]
            if (i == 1):
                matrix_of_bindings_type[k] = [element, False, True, False, False]
            if (i == 2):
                matrix_of_bindings_type[k] = [element, False, False, True, False]
            if (i == 3):
                matrix_of_bindings_type[k] = [element, False, False, False, True]
            k = k + 1
    for i in range(len(non_frame_elements)):
        matrix_of_bindings_type[k][0] = non_frame_elements[i]
        k = k + 1

    return matrix_of_bindings_type


def get_kind_of_binding(image,side):    #Funkcja zwraca rodzaj danej wypustki
    if(side=="top"):
        x=range(len(image)//2)  #Sprawdzamy tylko do połowy wymiaru - wypustka nigdy nie będzie większa
    elif(side=="bottom"):
        x=range(len(image)-1,len(image)//2,-1)
    elif(side=="left"):
        df=pd.DataFrame(image).T
        image=df.values.tolist()
        x=range(len(image)//2)

    elif(side=="right"):
        df=pd.DataFrame(image).T
        image=df.values.tolist()
        x=range(len(image)-1,len(image)//2,-1)

    kind=""

    for i in x:
        if(side=="top" or side=="left"):
            limit=i                     #limit oznacza numer sprawdzanego wiersza
        elif(side=="bottom" or side=="right"):
            limit=abs(i-len(image)+1)

        ## WYJAŚNIENIE
        ### Sprawdzamy co dzieje się przez 10% wymiaru (wartość empiryczna)
        ### Wypustkę wklęsłą ustalamy, gdy znajdziemy wiersz w którym mamy piksele kolorowe - pusty obszar - piksele kolorowe
        ### Wypustka wypukła charkateryzuje się tym, że po 10% wymiarów nie zajdzie warunek na wypustkę wklęsłą
        start=-1
        stop=-1
        number_of_rows=0
        for j in range(len(image[i])):
            if(image[i][j]!=(0,0,0,0) and start==-1):
                start=j
            elif(image[i][j]==(0,0,0,0) and start>-1):
                if number_of_rows==0:
                    stop=j
                number_of_rows+=1
            elif(image[i][j]!=(0,0,0,0) and stop>-1 ):
                number_of_rows+=1
                if (limit<len(image)//8):
                    kind = "wklesle"
                break

            if limit>len(image)//8 and kind!="wklesle" :
                kind="wypukle"

        if kind=="wklesle" or kind=="wypukle":
            break

    return kind


def final_matrix_of_bindings_kind(matrix_of_bindings_type,
                                  directory):  # Funkcja zwraca tablicę z rodzajami wypustek i wektor z rodzajem puzzla
    sides = ['top', 'bottom', 'left', 'right']
    path = directory
    matrix_of_bindings_type_strings = [[0] * len(matrix_of_bindings_type[0]) for i in
                                       range(len(matrix_of_bindings_type))]
    vector_of_type = []
    for i in range(len(matrix_of_bindings_type_strings)):
        matrix_of_bindings_type_strings[i][0] = matrix_of_bindings_type[i][0]  # kolumna 0 to nazwa pliku
        ramka = 0
        for j in range(1, 5):  # kolumny od 1 do 5 mówią o rodzaju wypustki

            if (matrix_of_bindings_type[i][j] == True):
                matrix_of_bindings_type_strings[i][j] = 'ramka'
                ramka += 1
            else:
                image = getPixels(path + "//" + matrix_of_bindings_type[i][0])
                matrix_of_bindings_type_strings[i][j] = get_kind_of_binding(image, sides[j - 1])
        if (ramka == 0):
            vector_of_type.append('non_frame')  # wektor z rodzajem puzzla

        elif (ramka == 1):
            vector_of_type.append('frame')

        else:
            vector_of_type.append('corner')
    return matrix_of_bindings_type_strings, vector_of_type

def transform_arrays_to_df(type_string,metrics,vector):     #Przekształcenie tabeli do ramki danych
    df_type_binding=pd.DataFrame(type_string)
    df_metrics_binding=pd.DataFrame(metrics)
    df_type_binding['type']=np.array(vector).T

    return df_type_binding.merge(df_metrics_binding,on=0)


# Funkcja rozszerzająca ramkę danych o puzzle, które mogłyby powstać w wyniku obrotu
# Dodatkowo tworzymy kolumnę `id`, która identyfikuje obserwację oraz `rotation` oznaczającą kąt o jaki puzzel został obrócony
def create_whole_df_with_rotations(whole_df2):
    data_frames = []
    chain_of_changes = [1, 4, 2, 3]
    columns_to_change_value = ['1_x', '2_x', '3_x', '4_x', '1_y', '2_y', '3_y',
                               '4_y', '1_c', '2_c', '3_c', '4_c', '1_d', '2_d', '3_d', '4_d']
    for i in range(1, 4):
        df = pd.DataFrame(columns=whole_df2.columns)
        for column in columns_to_change_value:
            number = int(column[0])
            position_in_chain = chain_of_changes.index(number)
            next_position = (position_in_chain + i) % 4
            name = str(chain_of_changes[next_position]) + column[1:]
            df[name] = whole_df2[column]
        df[0] = whole_df2[0]
        df['type'] = whole_df2['type']
        df['rotation'] = -90 * i
        df['id'] = df[0] + str(90 * i)
        data_frames.append(df)
    whole_df2['id'] = whole_df2[0] + '0'
    return pd.concat([whole_df2, data_frames[0], data_frames[1], data_frames[2]])


# Wybieramy losową liczbę puzzli do obrócenia o losową wielokrotność 90 stopni
def rotate_random_number_of_elements(whole_df2, directory):
    subset = whole_df2[whole_df2['type'] != 'corner']
    sequence = [i for i in range(len(subset))]
    number_of_rotate_elements = random.randint(1, len(subset))
    subset_id = random.sample(sequence, number_of_rotate_elements)
    for i in subset_id:
        file_name = subset.iloc[i][0]
        im = Image.open(f"{directory}/{file_name}")
        im.rotate(-90 * random.randint(1, 3), expand=True).save(f"{directory}/{file_name}")


