import os
import numpy as np

from solving_image import if_final_matrix_element2, check_if_subset, get_colors, messages_frame, matching_frame


# Przykładowo wartość `top` oznacza sposób układania górnej ramki
def values_of_binding_columns(side):  # Wartości przy dopasowywaniu poszczególnych stron
    if (side == 'top'):
        binding = '4_x'
        binding_next = '3_x'
        binding_value = '4_y'
        binding_next_value = '3_y'
        condition = '1_x'

    elif (side == 'bottom'):
        binding = '4_x'
        binding_next = '3_x'
        binding_value = '4_y'
        binding_next_value = '3_y'
        condition = '2_x'

    elif (side == 'left'):
        binding = '2_x'
        binding_next = '1_x'
        binding_value = '2_y'
        binding_next_value = '1_y'
        condition = '3_x'

    elif (side == 'right'):
        binding = '2_x'
        binding_next = '1_x'
        binding_value = '2_y'
        binding_next_value = '1_y'
        condition = '4_x'

    return binding, binding_next, binding_value, binding_next_value, condition


# Funkcja wybiera wszystkie puzzle z ramki o odpowiednim kształcie
# Zwraca kolejny puzzel
def solved_puzzle_frame(whole_df, first_puzzle, side, directory, final_matrix):
    path =  directory
    path_el = os.listdir(path)

    binding, binding_next, binding_value, binding_next_value, condition = values_of_binding_columns(side)

    if (first_puzzle.iloc[0][binding] == 'wklesle'):  # Oddzielne warunki na układanie ramki
        next_possible_puzzle = whole_df[(whole_df[condition] == 'ramka') & (whole_df[binding_next] == "wypukle")]
    else:
        next_possible_puzzle = whole_df[(whole_df[condition] == 'ramka') & (whole_df[binding_next] == "wklesle")]

    vector_of_possible_puzzles = if_final_matrix_element2(list(next_possible_puzzle['id']), final_matrix)
    possible_puzzles_without_removed = next_possible_puzzle[next_possible_puzzle['id'].isin(vector_of_possible_puzzles)]

    next_puzzle = matching_frame(possible_puzzles_without_removed, first_puzzle, binding_value, binding_next_value)

    rem_puzzles = []
    if (len(vector_of_possible_puzzles) == 0):
        rem_puzzles = if_final_matrix_element2(list(whole_df[whole_df['type'] == 'frame']['id']), final_matrix)
        print(rem_puzzles)
    return messages_frame(next_puzzle, possible_puzzles_without_removed, first_puzzle, whole_df, binding_value,
                          binding_next_value, final_matrix, rem_puzzles)



def solving_puzzle_frame(whole_df, final_matrix, directory):  # Układamy całą ramkę
    height = len(final_matrix)
    width = len(final_matrix[0])

    sides = ['top', 'bottom', 'left', 'right']
    limit = [width, width, height, height]
    corners = [final_matrix[0][0], final_matrix[-1][0], final_matrix[0][0],
               final_matrix[0][-1]]  # Narożniki, od których będziemy układać

    number_of_accurate_matching = 0
    number_of_iteration = 0

    for i in range(len(sides)):
        flag = True
        first_puzzle = whole_df[(whole_df['id'] == corners[i])]
        for j in range(limit[i] - 1):
            # print(i,j)
            if (flag == False):
                if (i == 0 or i == 1):
                    if (i == 0):
                        x = 0
                    else:
                        x = -1
                    final_matrix[x][j] = rem_puzzles[ind]

                else:
                    if (i == 2):
                        x = 0
                    else:
                        x = -1
                    final_matrix[j][x] = rem_puzzles[ind]
                ind += 1
            else:
                if (i == 0 or i == 1):
                    if (i == 0):
                        x = 0
                    else:
                        x = -1
                    final_matrix[x][j] = first_puzzle.iloc[0]['id']
                else:
                    if (i == 2):
                        x = 0
                    else:
                        x = -1
                    final_matrix[j][x] = first_puzzle.iloc[0]['id']

            if (j < limit[i] - 2):
                next_puzzle_element, is_accurate_matching = solved_puzzle_frame(whole_df, first_puzzle, sides[i],
                                                                                directory, final_matrix)
                number_of_accurate_matching += is_accurate_matching
                if (is_accurate_matching == -1):
                    flag = False
                    rem_puzzles = if_final_matrix_element2(list(whole_df[whole_df['type'] == 'frame']['id']),
                                                           final_matrix)
                    ind = 0
                    continue
                number_of_iteration += 1

                first_puzzle = whole_df[(whole_df['id'] == next_puzzle_element)]

    return final_matrix, round(number_of_accurate_matching / number_of_iteration, 2)


# funkcja mówiąca, które krawędzie mamy łączyć ze sobą przy układaniu środka obrazka i rozpoczynania od różnych narożników
def values_of_binding_columns_non_frame(side):  # Wartości przy dopasowywaniu poszczególnych stron
    if (side == 'left_top'):
        binding_first = '1_x'
        binding_first_next = '2_x'
        binding_second = '4_x'
        binding_second_next = '3_x'

        binding_first_value = '1_y'
        binding_first_next_value = '2_y'
        binding_second_value = '4_y'
        binding_second_next_value = '3_y'

    elif (side == 'right_top'):
        binding_first = '1_x'
        binding_first_next = '2_x'
        binding_second = '3_x'
        binding_second_next = '4_x'

        binding_first_value = '1_y'
        binding_first_next_value = '2_y'
        binding_second_value = '3_y'
        binding_second_next_value = '4_y'

    elif (side == 'left_bottom'):
        binding_first = '2_x'
        binding_first_next = '1_x'
        binding_second = '4_x'
        binding_second_next = '3_x'

        binding_first_value = '2_y'
        binding_first_next_value = '1_y'
        binding_second_value = '4_y'
        binding_second_next_value = '3_y'

    elif (side == 'right_bottom'):
        binding_first = '2_x'
        binding_first_next = '1_x'
        binding_second = '3_x'
        binding_second_next = '4_x'

        binding_first_value = '2_y'
        binding_first_next_value = '1_y'
        binding_second_value = '3_y'
        binding_second_next_value = '4_y'

    return binding_first, binding_first_next, binding_second, binding_second_next, binding_first_value, binding_first_next_value, binding_second_value, binding_second_next_value


#Sposób układania puzzli dla poszczególnych narożników
def get_additional_puzzles(side,width,height):
    if(side=='left_top'):
        first_indices=-1,0
        second_indices=0,-1
        x=range(1,height-1)
        y=range(1,width-1)
    elif(side=='right_top'):
        first_indices=-1,0
        second_indices=0,1
        x=range(1,height-1)
        y=range(width-2,0,-1)
    elif(side=='left_bottom'):
        first_indices=1,0
        second_indices=0,-1
        x=range(height-2,0,-1)
        y=range(1,width-1)
    else:
        first_indices=1,0
        second_indices=0,1
        x=range(height-2,0,-1)
        y=range(width-2,0,-1)

    return first_indices,second_indices,x,y





