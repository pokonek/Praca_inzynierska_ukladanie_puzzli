from additional_function_to_solving import solving_puzzle_frame
from creating_df import create_matrix_of_bindings_type, final_matrix_of_bindings_kind, transform_arrays_to_df, \
    create_whole_df_with_rotations, rotate_random_number_of_elements
from metrics import metrics_of_bindings, colors_of_pixels
from solving_image import create_final_matrix, solving_whole_image
from visu import matrix_of_translation, visualization


def number_of_rows_and_columns(directory,rotations=False):

    type_boolean=create_matrix_of_bindings_type(directory)
    type_string,types_of_elements=final_matrix_of_bindings_kind(type_boolean,directory)
    metrics2=metrics_of_bindings(type_string,directory,6)
    whole_df2=transform_arrays_to_df(type_string,metrics2,types_of_elements)
    rows,columns=len(whole_df2[whole_df2['3_x']=='ramka']),len(whole_df2[whole_df2['1_x']=='ramka'])

    if(rotations):
        return whole_df2

    return whole_df2,rows,columns


def get_result(directory, whole_df2,rows, columns,side):

    final_matrix=create_final_matrix(rows,columns,whole_df2)

    solved_frame,acc_f=solving_puzzle_frame(whole_df2,final_matrix,directory)
                                                                              #acc_f - % idelanych dopasowań dla ramki
    result,acc_nf=solving_whole_image(whole_df2,directory,final_matrix,side)

    return result,acc_nf


def demonstrator_without_rotations(directory):

    side='left_top'

    whole_df2,rows,columns=number_of_rows_and_columns(directory)
    whole_df2=colors_of_pixels(directory,whole_df2)
    whole_df2=create_whole_df_with_rotations(whole_df2)
    result,acc_nf=get_result(directory, whole_df2,rows, columns,side)

    return result,whole_df2,acc_nf


def demonstrator_with_rotations(directory):
    side = 'left_top'

    whole_df2, rows, columns = number_of_rows_and_columns(directory)
    rotate_random_number_of_elements(whole_df2, directory)

    whole_df2 = number_of_rows_and_columns(directory, True)
    whole_df2 = colors_of_pixels(directory, whole_df2)
    whole_df2 = create_whole_df_with_rotations(whole_df2)

    result, acc_nf = get_result(directory, whole_df2, rows, columns, side)

    print(acc_nf)

    return result, whole_df2


def demonstrator_rotations_corners(directory):
    sides = ['left_top', 'right_top', 'left_bottom', 'right_bottom']
    results = []
    acc_nfs = []

    whole_df2, rows, columns = number_of_rows_and_columns(directory)
    rotate_random_number_of_elements(whole_df2, directory)

    whole_df2 = number_of_rows_and_columns(directory, True)
    whole_df2 = colors_of_pixels(directory, whole_df2)
    whole_df2 = create_whole_df_with_rotations(whole_df2)

    for side in sides:
        result, acc_nf = get_result(directory, whole_df2, rows, columns, side)
        print(acc_nf)
        if (acc_nf > 0.9):
            return result, whole_df2
        results.append(result)
        acc_nfs.append(acc_nf)

    final_result = results[acc_nfs.index(max(acc_nfs))]
    return final_result, whole_df2


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    final_result, whole_df2,acc_nf=demonstrator_without_rotations('raster')
    matrix = matrix_of_translation(final_result, whole_df2, "raster")
    visualization(final_result, matrix, whole_df2, "raster").show()


