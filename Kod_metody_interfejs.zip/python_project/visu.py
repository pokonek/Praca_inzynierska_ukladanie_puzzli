import re

from PIL import Image


def dimensions(result,directory):       #Zwraca maksymalne wymiary ostatecznego obrazka - zawsze będą mniejsze
    whole_width=0
    whole_height=0
    for i in range(len(result[0])):
        image=Image.open(directory+"//"+re.sub(r'\d+$', '',str(result[0][i])), 'r')
        whole_width+=image.width

    for i in range(len(result)):
        image=Image.open(directory+"//"+re.sub(r'\d+$', '',str(result[i][0])), 'r')
        whole_height+=image.height

    return whole_height, whole_width


def matrix_of_translation(result, whole_df2,
                          directory):  # Zwraca pozycję, na których powinny się znaleźć poszczególne puzzle w wizualizacji
    matrix = [[0] * len(result[0]) for i in range(len(result))]
    matrix[0][0] = [result[0][0], 0, 0]

    for i in range(1, len(result[0])):  # Najpierw znajdujemy pozycje górnej ramki
        tmp_puzzle = whole_df2[whole_df2['id'] == result[0][i]]
        prev_puzzle = whole_df2[whole_df2['id'] == result[0][i - 1]]
        image = Image.open(directory + "//" + re.sub(r'\d+$', '', str(result[0][i - 1])), 'r')
        image = image.rotate(prev_puzzle.iloc[0]['rotation'], expand=True)  # Obrót puzzla zgodnie z kolumną `rotation`
        if (prev_puzzle.iloc[0]['4_x'] == 'wklesle'):
            translation = prev_puzzle.iloc[0]['4_d']
        else:
            translation = tmp_puzzle.iloc[0]['3_d']
        x_trans = matrix[0][i - 1][1] + image.width - translation + 2  # Wyliczam pozycję od lewej; od góry równa 0
        matrix[0][i] = [result[0][i], x_trans, 0]

    for i in range(1, len(result)):  # Potem znajdujemy pozycje kawałków z lewej strony ramki
        tmp_puzzle = whole_df2[whole_df2['id'] == result[i][0]]
        prev_puzzle = whole_df2[whole_df2['id'] == result[i - 1][0]]
        image = Image.open(directory + "//" + re.sub(r'\d+$', '', str(result[i - 1][0])), 'r')
        image = image.rotate(prev_puzzle.iloc[0]['rotation'], expand=True)
        if (prev_puzzle.iloc[0]['2_x'] == 'wklesle'):
            translation = prev_puzzle.iloc[0]['2_d']
        else:
            translation = tmp_puzzle.iloc[0]['1_d']

        y_trans = matrix[i - 1][0][2] + image.height - translation + 2
        matrix[i][0] = [result[i][0], 0, y_trans]

    for i in range(1, len(result)):  # Pozycje wszystkich pozostałych puzzli
        for j in range(1, len(result[0])):
            if (result[i][j] == 0):
                return matrix
            tmp_puzzle = whole_df2[whole_df2['id'] == result[i][j]]
            left_puzzle = whole_df2[whole_df2['id'] == result[i][j - 1]]
            top_puzzle = whole_df2[whole_df2['id'] == result[i - 1][j]]

            image_left = Image.open(directory + "//" + re.sub(r'\d+$', '', str(result[i][j - 1])), 'r')

            image_left = image_left.rotate(left_puzzle.iloc[0]['rotation'], expand=True)

            image_top = Image.open(directory + "//" + re.sub(r'\d+$', '', str(result[i - 1][j])), 'r')
            image_top = image_top.rotate(top_puzzle.iloc[0]['rotation'], expand=True)

            if (left_puzzle.iloc[0]['4_x'] == 'wklesle'):
                translation_x = left_puzzle.iloc[0]['4_d']
            else:
                translation_x = tmp_puzzle.iloc[0]['3_d']

            if (top_puzzle.iloc[0]['2_x'] == 'wklesle'):
                translation_y = top_puzzle.iloc[0]['2_d']
            else:
                translation_y = tmp_puzzle.iloc[0]['1_d']

            x_trans = matrix[i][j - 1][
                          1] + image_left.width - translation_x + 2  # +2, żeby było widać łączenia między puzzlami
            y_trans = matrix[i - 1][j][2] + image_top.height - translation_y + 2
            matrix[i][j] = [result[i][j], x_trans, y_trans]

    return matrix


def visualization(result, matrix, whole_df2, directory):  # Ostateczna wizualizacja

    dim = dimensions(result, directory)
    text_img = Image.new('RGBA', (dim[1], dim[0]), (0, 0, 0, 0))

    filename = directory + '//' + re.sub(r'\d+$', '', str(result[0][0]))
    image = Image.open(filename, 'r')
    text_img.paste(image, (matrix[0][0][1], matrix[0][0][2]))

    for i in range(len(result[0])):  # Układamy pierwszy wiersz od góry
        filename = directory + '//' + re.sub(r'\d+$', '', str(result[0][i]))
        image = Image.open(filename, 'r').convert('RGBA')
        image = image.rotate(whole_df2[whole_df2['id'] == result[0][i]].iloc[0]['rotation'], expand=True)
        text_img.paste(image, (matrix[0][i][1], matrix[0][i][2]), mask=image)

    for i in range(len(result)):  # Układamy pierwszą kolumnę od lewej
        filename = directory + '//' + re.sub(r'\d+$', '', str(result[i][0]))
        image = Image.open(filename, 'r').convert('RGBA')
        image = image.rotate(whole_df2[whole_df2['id'] == result[i][0]].iloc[0]['rotation'], expand=True)
        text_img.paste(image, (matrix[i][0][1], matrix[i][0][2]), mask=image)

    for i in range(1, len(result)):  # Znajdujemy pozycje pozostałych puzzli; układamy od góry z lewej do prawej
        for j in range(1, len(result[0])):
            if (re.sub(r'\d+$', '', str(result[i][j])) == 0):
                return text_img
            filename = directory + '//' + re.sub(r'\d+$', '', str(result[i][j]))
            image = Image.open(filename, 'r').convert('RGBA')
            image = image.rotate(whole_df2[whole_df2['id'] == result[i][j]].iloc[0]['rotation'], expand=True)
            text_img.paste(image, (matrix[i][j][1], matrix[i][j][2]), mask=image)

    return text_img