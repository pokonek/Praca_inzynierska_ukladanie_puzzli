import os
import pandas as pd
from bs4 import BeautifulSoup
import re


def get_true_matrix_of_puzzles(directory,file):     #Zwraca poprawność kolejność i pozycję na końcowej wizualizację - dane z biblioteki do cięcia obrazków
    path = directory
    path_el=os.listdir(path)
    left_top=[[0]*2 for i in range(len(path_el))]

    with open(file) as fp:
        soup = BeautifulSoup(fp, 'html.parser')     #Pobieramy dane z obrazka z poprawnie ułożonymi puzzlami
    for i in range(len(path_el)):
        div_object=soup.find(id=f'p-{i}')
        attrib=div_object['style']
        left_top[i]=re.findall(r'\d+', attrib)

    df=pd.DataFrame(left_top)
    df=df.astype('int32')
    df=df.sort_values([1])
    df['index1'] = df.index

    number_of_columns=len(df[df[1]==0])
    number_of_rows=len(path_el)//number_of_columns
    result=[[0]*number_of_columns for i in range(number_of_rows)]
    result_left_top=[[0]*number_of_columns for i in range(number_of_rows)]
    for i in range(number_of_rows):
        row_sorted=df.iloc[number_of_columns*i:number_of_columns*(i+1)].sort_values([0])
        for j in range(len(row_sorted)):
            result[i][j]=str(row_sorted.iloc[j]['index1'])+'.png'
            result_left_top[i][j]=[str(row_sorted.iloc[j]['index1'])+'.png',row_sorted.iloc[j][0],row_sorted.iloc[j][1]]

    return result_left_top,pd.DataFrame(result)

#Zwraca wyznaczoną dokładność puzzli na odpowiednim miejscu
def stats(df,df_true):
    k=0
    no_elem=len(df)*len(df.iloc[0])
    for i in range(len(df)):
        for j in range(len(df.iloc[0])):
            zz=re.sub(r'\d+$', '',df.iloc[i][j])
            if zz==df_true.iloc[i][j]:
                k=k+1
    return k/no_elem


#Dokładność dla elementów ramki
def stats_frame(df,df_true):
    k=0
    no_elem=0
    for i in range(len(df)):
        zz=re.sub(r'\d+$', '',df.iloc[i][0])
        zzz=re.sub(r'\d+$', '',df.iloc[i][len(df.iloc[0])-1])
        if zz==df_true.iloc[i][0]:
            k=k+1

        if zzz==df_true.iloc[i][len(df.iloc[0])-1]:
            k=k+1
        no_elem+=2

    for i in range(1,len(df.iloc[0])-1):
        zz=re.sub(r'\d+$', '',df.iloc[0][i])
        zzz=re.sub(r'\d+$', '',df.iloc[len(df)-1][i])

        if zz==df_true.iloc[0][i]:
            k=k+1

        if zzz==df_true.iloc[len(df)-1][i]:
            k=k+1
        no_elem+=2
    return k/no_elem


#Dla pozostałych elementów przyjmujemy konwencję, że za każdego dobrze wyznaczonego sąsiada przyznajemy 0.25 punktu
def stats_non_frame(df,df_true):
    k=0
    no_elem=0
    for i in range(1,len(df)-1):
        for j in range(1,len(df.iloc[0])-1):
            re.sub(r'\d+$', '',df.iloc[i-1][j])
            if re.sub(r'\d+$', '',df.iloc[i-1][j])==df_true.iloc[i-1][j]:
                k=k+0.25

            if re.sub(r'\d+$', '',df.iloc[i+1][j])==df_true.iloc[i+1][j]:
                k=k+0.25

            if re.sub(r'\d+$', '',df.iloc[i][j-1])==df_true.iloc[i][j-1]:
                k=k+0.25

            if re.sub(r'\d+$', '',df.iloc[i][j+1])==df_true.iloc[i][j+1]:
                k=k+0.25

            no_elem+=1

    return k/no_elem

#Blok związany z wyznaczaniem statystyk
def all_stats(df,df_true):
    wynik1=stats(df,df_true)
    wynik2=stats_frame(df,df_true)
    wynik3=stats_non_frame(df,df_true)
    print('------------------------------')
    print(f'Liczba puzzli: {len(df)*len(df.iloc[0])}')
    print('------------------------------')
    print(f'Dokładność: {round(wynik1,2)}')
    print('------------------------------')
    print(f'Dokładność dla ramki: {round(wynik2,2)}')
    print('------------------------------')
    print(f'Dokładność dla puzzli spoza ramki: {round(wynik3,2)}')
    print('------------------------------')



