import os

from PIL import ImageFont
from PIL import ImageDraw
import re
import numpy as np
import pandas as pd
import keras
from PIL import Image
from metrics import getPixels
from solving_image import if_final_matrix_element2

model_left2 = keras.models.load_model('D:\\piotr\\7 semestr\\model_left_2.keras')
model_top2 = keras.models.load_model('D:\\piotr\\7 semestr\\model_top_2.keras')

max_left=[142,149,108,108]
max_top=[178,178,105,105]

def width_height(id_left, directory):
    file = re.sub(r'\d+$', '', id_left)

    file_path = directory + "\\" + file
    image = getPixels(file_path)
    height = len(image)
    width = len(image[0])

    return [height, width]

def create_df_with_next_possible_vectors(whole_df2, id_left, directory):
    counter = 0
    data_neural_network_left = whole_df2[['id', '4_x', '4_y', '4_c', '4_d', 'type']]
    data_neural_network_right = whole_df2[['id', '3_x', '3_y', '3_c', '3_d', 'type']]

    all_columns_left = ['id_left', '4_x_left', '4_y_left', '4_c_left', '4_d_left', 'type_left', 'height_left',
                        'width_left',
                        'id_right', '3_x_right', '3_y_right', '3_c_right', '3_d_right', 'type_right', 'height_right',
                        'width_right']
    df_left_nn2 = pd.DataFrame(columns=all_columns_left)

    value_left = data_neural_network_left[data_neural_network_left['id'] == id_left]
    width_height_l = width_height(id_left, directory)

    for j in range(len(data_neural_network_right)):
        id_right = data_neural_network_right.iloc[j]['id']
        if (id_right == id_left):
            continue
        width_height_r = width_height(id_right, directory)

        record = list(value_left.iloc[0]) + width_height_l + list(data_neural_network_right.iloc[j]) + width_height_r
        df_left_nn2.loc[counter, :] = record
        counter += 1

    return df_left_nn2

def create_df_with_next_possible_vectors_top(whole_df2,id_left,directory):
    counter=0
    data_neural_network_left=whole_df2[['id','2_x','2_y','2_c','2_d','type']]
    data_neural_network_right=whole_df2[['id','1_x','1_y','1_c','1_d','type']]

    all_columns_top=['id_top','2_x_top','2_y_top','2_c_top','2_d_top','type_top','height_top','width_top',
            'id_bottom','1_x_bottom','1_y_bottom','1_c_bottom','1_d_bottom','type_bottom','height_bottom','width_bottom']
    df_left_nn2 = pd.DataFrame(columns=all_columns_top)

    value_left=data_neural_network_left[data_neural_network_left['id']==id_left]
    width_height_l=width_height(id_left,directory)

    for j in range(len(data_neural_network_right)):
        id_right=data_neural_network_right.iloc[j]['id']
        if(id_right==id_left):
            continue
        width_height_r=width_height(id_right,directory)

        record=list(value_left.iloc[0])+width_height_l+list(data_neural_network_right.iloc[j])+width_height_r
        df_left_nn2.loc[counter,:]=record
        counter+=1


    return df_left_nn2

def replace_none_with_empty_list(x):
    if x is None:
        return []
    else:
        return x

def first_pipeline(df_left_nn2):
    df_left_nn2 = df_left_nn2.replace({'ramka': 0, 'wklesle': 1, 'wypukle': 2, 'corner': 0, 'frame': 1, 'non_frame': 2})
    df_left_nn2 = df_left_nn2.applymap(replace_none_with_empty_list)
    df_left_nn2 = df_left_nn2.reset_index(drop=True)

    return df_left_nn2
def simulation_rate(whole_df2, id, directory, final_matrix):
    zz = create_df_with_next_possible_vectors(whole_df2, id, directory)
    zzz = first_pipeline(zz)

    columns2 = ['4_c_left', '3_c_right']
    for column in columns2:
        for i in range(len(zzz)):
            a = zzz.at[i, column]
            zzz.at[i, column] = [j for sub in a for j in sub]
            del zzz.at[i, column][3::4]

    columns = ['4_y_left', '3_y_right', '4_c_left', '3_c_right']

    iter = 0
    for column in columns:
        for i in range(len(zzz)):

            if (len((zzz.at[i, column])) > max_left[iter]):
                zzz.at[i, column] = zzz.at[i, column][:max_left[iter]]
            x = np.pad(zzz.at[i, column], (0, max_left[iter] - len(zzz.at[i, column])), 'constant')

            zzz.at[i, column] = list(x)
        iter += 1

    v = list(zzz.iloc[:]['id_right'])
    indices = if_final_matrix_element2(v, final_matrix)
    zzz = zzz[zzz['id_right'].isin(indices)]
    zzz = zzz[zzz['4_x_left'] != zzz['3_x_right']]

    return zzz


def simulation_rate_top(whole_df2, id, directory, final_matrix):
    zz = create_df_with_next_possible_vectors_top(whole_df2, id, directory)
    zzz = first_pipeline(zz)

    columns2 = ['2_c_top', '1_c_bottom']

    for column in columns2:
        for i in range(len(zzz)):
            a = zzz.at[i, column]
            zzz.at[i, column] = [j for sub in a for j in sub]
            del zzz.at[i, column][3::4]

    columns = ['2_y_top', '1_y_bottom', '2_c_top', '1_c_bottom']

    iter = 0
    for column in columns:
        for i in range(len(zzz)):
            if (len((zzz.at[i, column])) > max_top[iter]):
                zzz.at[i, column] = zzz.at[i, column][:max_top[iter]]
            x = np.pad(zzz.at[i, column], (0, max_top[iter] - len(zzz.at[i, column])), 'constant')

            zzz.at[i, column] = list(x)
        iter += 1

    v = list(zzz.iloc[:]['id_bottom'])
    indices2 = if_final_matrix_element2(v, final_matrix)
    zzz = zzz[zzz['id_bottom'].isin(indices2)]
    zzz = zzz[zzz['2_x_top'] != zzz['1_x_bottom']]

    return zzz

def create_final_matrix_nn(whole_df2):
    columns=len(whole_df2[(whole_df2['1_x']=='ramka')&(whole_df2['rotation']==0)])
    rows=len(whole_df2[(whole_df2['4_x']=='ramka')&(whole_df2['rotation']==0)])

    return columns,rows


def create_intersection(zzz,zzz2):
    final_left=pd.DataFrame(columns=zzz.columns)
    final_top=pd.DataFrame(columns=zzz2.columns)

    vector=list(zzz2['id_bottom'])
    counter=0

    for i in range(len(zzz)):
        if(zzz.iloc[i]['id_right'] in vector):
            final_left.loc[counter,:]=list(zzz.iloc[i])
            final_top.loc[counter,:]=list(zzz2[zzz2['id_bottom']==zzz.iloc[i]['id_right']].iloc[0])
            counter+=1
    return final_left, final_top


def pipeline_for_final_frame_top(final_top):
    columns = ['2_y_top', '1_y_bottom', '2_c_top', '1_c_bottom']
    arr_of_results2 = []

    for column in columns:
        result = []
        for i in range(len(final_top)):
            result.append(list(final_top.iloc[i][column]))

        result = np.array(result)
        arr_of_results2.append(result)

    final_top = pd.get_dummies(final_top, prefix=['2_x_top', 'type_top', '1_x_bottom', 'type_bottom'],
                               columns=['2_x_top', 'type_top', '1_x_bottom', 'type_bottom'], dtype=float)

    columnss = ['2_x_top_0', '2_x_top_1', '2_x_top_2', '1_x_bottom_0', '1_x_bottom_1', '1_x_bottom_2', 'type_top_0',
                'type_top_1', 'type_top_2', 'type_bottom_0', 'type_bottom_1', 'type_bottom_2']
    for column in columnss:
        if column not in final_top.columns:
            final_top[column] = 0.0

    final_top_without_lists = final_top[['height_top', 'width_top', 'height_bottom', 'width_bottom',
                                         '2_x_top_0', '2_x_top_1', '2_x_top_2', 'type_top_0', 'type_top_1',
                                         'type_top_2', '1_x_bottom_0', '1_x_bottom_1', '1_x_bottom_2',
                                         'type_bottom_0', 'type_bottom_1', 'type_bottom_2']]

    return np.asarray(final_top_without_lists).astype('float32'), arr_of_results2, final_top


def pipeline_for_final_frame_left(final_left):
    columns = ['4_y_left', '3_y_right', '4_c_left', '3_c_right']
    arr_of_results = []

    for column in columns:
        result = []
        for i in range(len(final_left)):
            result.append(list(final_left.iloc[i][column]))

        result = np.array(result)
        arr_of_results.append(result)

    final_left = pd.get_dummies(final_left, prefix=['4_x_left', 'type_left', '3_x_right', 'type_right'],
                                columns=['4_x_left', 'type_left', '3_x_right', 'type_right'], dtype=float)

    columnss = ['4_x_left_0', '4_x_left_1', '4_x_left_2', '3_x_right_0', '3_x_right_1', '3_x_right_2', 'type_left_0',
                'type_left_1', 'type_left_2', 'type_right_0', 'type_right_1', 'type_right_2']
    for column in columnss:
        if column not in final_left.columns:
            final_left[column] = 0.0

    final_left_without_lists = final_left[['height_left', 'width_left', 'height_right', 'width_right',
                                           '4_x_left_0', '4_x_left_1', '4_x_left_2', 'type_left_0', 'type_left_1',
                                           'type_left_2', '3_x_right_0', '3_x_right_1', '3_x_right_2',
                                           'type_right_0', 'type_right_1', 'type_right_2']]

    return np.asarray(final_left_without_lists).astype('float32'), arr_of_results, final_left

def prediction(model,final_without_lists,arr_of_results):
    t=model.predict({'grid_input': arr_of_results[0],'grid_input2': arr_of_results[1],
                'grid_input3': arr_of_results[2],'grid_input4': arr_of_results[3], 'df_input': final_without_lists})

    return t


def all_changes_left(whole_df, directory, final_matrix, id_left, final_left):
    final_left_without_lists, arr_of_results, final_left = pipeline_for_final_frame_left(final_left)
    t_left = prediction(model_left2, final_left_without_lists, arr_of_results)

    return t_left, final_left


def all_changes_top(whole_df, directory, final_matrix, id_top, final_top):
    final_top_without_lists, arr_of_results, final_top = pipeline_for_final_frame_top(final_top)
    t_top = prediction(model_top2, final_top_without_lists, arr_of_results)

    return t_top, final_top


def get_indices_of_all_elements(directory):  # Funkcja zwraca tablicę z wszystkimi możliwymi id
    result = []
    path_el = os.listdir(directory)
    rotate = [0, 90, 180, 270]
    for element in path_el:
        for rotation in rotate:
            result.append(element + str(rotation))

    return result

def n_best_possible_puzzles(whole_df2, directory, final_matrix, id_top, id_left):
    final_left = simulation_rate(whole_df2, id_left, directory, final_matrix)
    final_top = simulation_rate_top(whole_df2, id_top, directory, final_matrix)
    final_left, final_top = create_intersection(final_left, final_top)
    result = []
    if(len(final_left)==0):
        result=if_final_matrix_element2(get_indices_of_all_elements(directory),final_matrix)
    else:
        t_top, final_top = all_changes_top(whole_df2, directory, final_matrix, id_top, final_top)
        t_left, final_left = all_changes_left(whole_df2, directory, final_matrix, id_left, final_left)
        t = t_left + t_top

        x = np.argsort(-t, axis=0)

        for i in range(len(final_left)):
            result.append(final_left.iloc[x[i][0]]['id_right'])

    return result


def visualization_of_possible_puzzles(text_img,next_possible_puzzles,whole_df2,directory,dim):
    if(len(dim)==5):
        tmp_height=420
    else:
        tmp_height=350
    tmp_width=50
    for i in range(len(next_possible_puzzles)):

        filename=directory+'//'+re.sub(r'\d+$', '',next_possible_puzzles[i])
        image = Image.open(filename, 'r')
        image = image.rotate(whole_df2[whole_df2['id']==next_possible_puzzles[i]].iloc[0]['rotation'], expand=True)
        image = image.resize((150,150))
        text_img.paste(image, (tmp_width,tmp_height))

        I1 = ImageDraw.Draw(text_img)
        myFont = ImageFont.truetype('arial.ttf', 28)
        I1.text((tmp_width+30, dim[0]-80),next_possible_puzzles[i], font=myFont, fill = 'black' )

        tmp_width+=200

    return text_img

def visualization_of_next_puzzles(whole_df2, next_possible_puzzles, directory, id_left, id_top, type_vis='non_frame'):
    if (type_vis == 'non_frame'):
        dim = [770, max(200 * (len(next_possible_puzzles) + 1), 500), 150, 150, 150]

    else:
        dim = [700, 200 * (len(next_possible_puzzles) + 1), 150, 150]

    text_img = Image.new('RGBA', (dim[1], dim[0]), (0, 0, 0, 0))
    I1 = ImageDraw.Draw(text_img)
    myFont = ImageFont.truetype('arial.ttf', 28)
    if type_vis == 'non_frame':
        I1.text((30, 30), "Dołóż puzzel pasujący do obu puzzli", font=myFont, fill = 'black')
        filename = directory + '//' + re.sub(r'\d+$', '', id_left)
        image = Image.open(filename, 'r')
        image = image.rotate(whole_df2[whole_df2['id'] == id_left].iloc[0]['rotation'], expand=True)
        image = image.resize((150, 150))
        text_img.paste(image, (dim[1] * 45 // 100 - dim[4], dim[3] + 50))

        filename = directory + '//' + re.sub(r'\d+$', '', id_top)
        image = Image.open(filename, 'r')
        image = image.rotate(whole_df2[whole_df2['id'] == id_top].iloc[0]['rotation'], expand=True)
        image = image.resize((150, 150))
        text_img.paste(image, (dim[1] * 45 // 100, 70))

    else:

        if (id_left == 0):
            id = id_top
            I1.text((30, 30), "Dołóż puzzel z dołu", font=myFont, fill = 'black')
        else:
            id = id_left
            I1.text((30, 30), "Dołóż puzzel z prawej", font=myFont, fill = 'black')
        filename = directory + '//' + re.sub(r'\d+$', '', id)
        image = Image.open(filename, 'r')
        image = image.rotate(whole_df2[whole_df2['id'] == id].iloc[0]['rotation'], expand=True)
        image = image.resize((150, 150))
        text_img.paste(image, (dim[1] // 2 - 75, 100))

    return visualization_of_possible_puzzles(text_img, next_possible_puzzles, whole_df2, directory, dim)
def prepare_color_columns(df):
    color_columns=['1_c','2_c','3_c','4_c']

    for column in color_columns:
        df=df.explode(column)

    return df

