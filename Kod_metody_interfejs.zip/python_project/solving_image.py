import os
import numpy as np
import re

def check_if_subset(vector1,vector2):  # Funkcja sprawdzająca, czy metryka wypustki wklęsłej jest zgodna z metryką wypukłej
    k = 0
    j = 0
    for i in range(len(vector1) - 1, -1, -1):
        if (vector1[i] == vector2[j]):
            k += 1
            j += 1
            if k == len(vector2):
                return True
            if j == len(vector2):
                break
        elif vector1[i] != vector2[j] and k > 0:
            if (vector1[i] == vector2[0]):
                k,j = 1,1
            else:
                k,j = 0,0

    return False


def get_indices_of_all_elements(directory):  # Funkcja zwraca tablicę z wszystkimi możliwymi id
    result = []
    path =  directory
    path_el = os.listdir(path)
    rotate = [0, 90, 180, 270]
    for element in path_el:
        for rotation in rotate:
            result.append(element + str(rotation))

    return result

def if_final_matrix_element2(vector,final_matrix):       #Sprawdzamy, czy element został już wcześniej wykorzystany

    result=list(map(lambda v: re.sub(r'\d+$', '', v) ,vector))
    matrix=list(map(lambda v: re.sub(r'\d+$', '', v) ,np.array(final_matrix).flatten()))


    return list(np.array(vector)[~np.array([item in matrix for item in result])])

#Funkcja wyznaczająca wartość dopasowania pomiędzy dwoma kolejnymi puzzlami
#Wybieramy puzzel z największą wartością funkcji dopasowania
#Zwracamy wartość dopasowania dla zadanych puzzli
def get_colors(next_puzzle,first_puzzle,binding_value,binding_next_value):
    color_value=binding_value[:-1]+'c'
    color_next_value=binding_next_value[:-1]+'c'
    distances=[]
    length=[]
    vector1=np.array(first_puzzle.iloc[0][color_value][0])
    for i in range(len(next_puzzle)):
        vector2=np.array(next_puzzle.iloc[i][color_next_value][0])

        length.append(len(vector2))
        if len(vector1)==len(vector2):                          #Podobieństwo kolorów obliczmy jako dystans w L2
            euclidean_distance=np.linalg.norm(vector1-vector2)
            distances.append(euclidean_distance)
        elif len(vector1)>len(vector2):                         #Dla wektorów różnej długości przycinamy dłuższy wektor kolorów
            euclidean_distance=np.linalg.norm(vector1[:len(vector2)]-vector2)
            distances.append(euclidean_distance)
        else:
            euclidean_distance=np.linalg.norm(vector1-vector2[:len(vector1)])
            distances.append(euclidean_distance)
    distances=np.array(distances)
    distances=(min(distances)+100)/(distances+100)              #Dodaję 100, żeby nie otrzymać 0 w mianowniku

    length=np.array(length)
    length=1/(abs(len(vector1)-length)+1)                       #Jeżeli dwa wektory mają identyczną długość, przyznajemy maksymalną liczbę punktów

    return 0.5*distances+0.5*length

def create_final_matrix(height,width,whole_df2):      #Tworzymy tablicę i wpisujemy do niej rozwiązaną ramkę

    final_matrix=[[0]*width for i in range(height)]
    final_matrix[0][0]=whole_df2[(whole_df2['1_x']=='ramka')&(whole_df2['3_x']=='ramka')&(whole_df2['rotation']==0)].iloc[0]['id'] #poszczególne narożniki
    final_matrix[0][-1]=whole_df2[(whole_df2['1_x']=='ramka')&(whole_df2['4_x']=='ramka')&(whole_df2['rotation']==0)].iloc[0]['id']
    final_matrix[-1][0]=whole_df2[(whole_df2['2_x']=='ramka')&(whole_df2['3_x']=='ramka')&(whole_df2['rotation']==0)].iloc[0]['id']
    final_matrix[-1][-1]=whole_df2[(whole_df2['2_x']=='ramka')&(whole_df2['4_x']=='ramka')&(whole_df2['rotation']==0)].iloc[0]['id']

    return final_matrix


# Funkcja wyszukuje kolejne możliwe puzzle do dopasowania oraz znajduje wszystkie puzzle niewykorzystane do tej pory
# Zwraca kolejny puzzel
def solving_puzzle_non_frame(whole_df, first_puzzle, side, directory, final_matrix, additional_puzzles):
    path =  directory
    path_el = os.listdir(path)

    second_puzzle = whole_df[(whole_df['id'] == additional_puzzles[0])]
    binding_first, binding_first_next, binding_second, binding_second_next, binding_first_value, binding_first_next_value, binding_second_value, binding_second_next_value = values_of_binding_columns_non_frame(
        side)

    if (first_puzzle.iloc[0][binding_first_next] == 'wklesle'):
        next_possible_puzzle = whole_df[(whole_df['type'] == 'non_frame') & (
                    whole_df[binding_second_next] != second_puzzle.iloc[0][binding_second]) & (
                                                    whole_df[binding_first] == "wypukle")]
    else:
        next_possible_puzzle = whole_df[(whole_df['type'] == 'non_frame') & (
                    whole_df[binding_second_next] != second_puzzle.iloc[0][binding_second]) & (
                                                    whole_df[binding_first] == "wklesle")]

    vector_of_possible_puzzles = if_final_matrix_element2(list(next_possible_puzzle['id']), final_matrix)
    possible_puzzles_without_removed = next_possible_puzzle[next_possible_puzzle['id'].isin(
        vector_of_possible_puzzles)]  # Dostępne puzzle bez tych wykorzystanych już wcześniej
    next_puzzle = matching_frame(possible_puzzles_without_removed, first_puzzle, binding_first_next_value,
                                 binding_first_value)  # Puzzle z dokładnym dopasowaniem

    remaining_puzzles = []

    if (len(vector_of_possible_puzzles) == 0):
        remaining_puzzles = if_final_matrix_element2(get_indices_of_all_elements(directory),
                                                     final_matrix)  # Wszystkie niewykorzystane puzzle
        return remaining_puzzles[0], 0

    next_puzzle2 = matching_non_frame(possible_puzzles_without_removed, second_puzzle, binding_second_value,
                                      binding_second_next_value)

    return messages_non_frame(next_puzzle, next_puzzle2, final_matrix, first_puzzle, second_puzzle, whole_df,
                              possible_puzzles_without_removed, remaining_puzzles,
                              binding_first_value, binding_first_next_value, binding_second_value,
                              binding_second_next_value)


# Szukamy dokładnego dopasowania wśród puzzli z pasującym kształtem wypustek
def matching_non_frame(next_possible_puzzle, second_puzzle, binding_value, binding_next_value):
    next_puzzle2 = []
    for i in range(len(next_possible_puzzle)):

        vector1 = second_puzzle.iloc[0][binding_value]
        vector2 = next_possible_puzzle.iloc[i][binding_next_value]

        if (len(vector1) < len(vector2)):
            vector1, vector2 = vector2, vector1
        flag = check_if_subset(vector1, vector2)

        if (flag == True):
            next_puzzle2.append(next_possible_puzzle.iloc[i]['id'])
    return next_puzzle2


# Funkcja rozwiązująca problem wyboru kolejnego puzzle
# W sytuacji dokładnego dopasowania wybieramy puzzel z najwyższą średnią wartością podobieństwa do 2 poprzednich puzzli (first_puzzel, second_puzzel)
# Przy braku dokładnego dopasowania wybieramy puzzel z tych, które mają odpowiednie kształty wypustek
# Przy braku puzzli z odpowidnimi kształtami wypustek wybieramy puzzel z tych niewykorzystanych do tej pory
def messages_non_frame(next_puzzle, next_puzzle2, final_matrix, first_puzzle, second_puzzle, whole_df,
                       next_possible_puzzle, remaining_puzzles,
                       binding_first_value, binding_first_next_value, binding_second_value, binding_second_next_value):
    common_part = np.intersect1d(next_puzzle, next_puzzle2)
    if (len(next_puzzle) > 0 and len(next_puzzle2) > 0):
        if (len(common_part) == 1):

            return common_part[0], 1

        elif (len(common_part) > 1):
            # Similarity_top mówi o stopniu podobieństwa do puzzla, znajdującego się bezpośrednio powyżej
            # Analogicznie similarity_left
            # Wyznaczamy średnią wartość i wybieramy element z największą wartością funkcji dopasowania
            similarity_top = get_colors(next_possible_puzzle[next_possible_puzzle['id'].isin(common_part)],
                                        first_puzzle, binding_first_next_value, binding_first_value)
            similarity_left = get_colors(next_possible_puzzle[next_possible_puzzle['id'].isin(common_part)],
                                         second_puzzle, binding_second_value, binding_second_next_value)
            similarity = (similarity_top + similarity_left) / 2

            index_max = np.argmax(similarity)

            return common_part[index_max], 0
        else:

            next_puzzle_all = next_puzzle + next_puzzle2
            similarity_top = get_colors(next_possible_puzzle[next_possible_puzzle['id'].isin(next_puzzle_all)],
                                        first_puzzle, binding_first_next_value, binding_first_value)

            similarity_left = get_colors(next_possible_puzzle[next_possible_puzzle['id'].isin(next_puzzle_all)],
                                         second_puzzle, binding_second_value, binding_second_next_value)
            similarity = (similarity_top + similarity_left) / 2

            index_max = np.argmax(similarity)
            returned_puzzle = next_possible_puzzle[next_possible_puzzle['id'].isin(next_puzzle_all)]

            return returned_puzzle.iloc[index_max]['id'], 0

    elif (len(next_possible_puzzle) == 0):  # Brak puzzli o odpowiednim kształcie wypustek
        values = whole_df[whole_df['id'].isin(remaining_puzzles)]
        similarity_top = get_colors(values, first_puzzle, binding_first_next_value, binding_first_value)

        similarity_left = get_colors(values, second_puzzle, binding_second_value, binding_second_next_value)
        similarity = (similarity_top + similarity_left) / 2
        index_max = np.argmax(similarity)

        return values.iloc[index_max]['id'], 0

    elif (len(next_puzzle2) == 0 and len(
            next_puzzle) == 0):  # Brak dokładnego dopasowania dla żadnego z dwóch poprzednich puzzli

        similarity_top = get_colors(next_possible_puzzle, first_puzzle, binding_first_next_value, binding_first_value)

        similarity_left = get_colors(next_possible_puzzle, second_puzzle, binding_second_value,
                                     binding_second_next_value)
        similarity = (similarity_top + similarity_left) / 2
        index_max = np.argmax(similarity)

        return next_possible_puzzle.iloc[index_max]['id'], 0

    elif (len(next_puzzle) == 0):

        similarity_left = get_colors(next_possible_puzzle[next_possible_puzzle['id'].isin(next_puzzle2)], second_puzzle,
                                     binding_second_value, binding_second_next_value)

        index_max = np.argmax(similarity_left)

        return next_puzzle2[index_max], 0

    elif (len(next_puzzle2) == 0):

        similarity_top = get_colors(next_possible_puzzle[next_possible_puzzle['id'].isin(next_puzzle)], first_puzzle,
                                    binding_first_next_value, binding_first_value)
        index_max = np.argmax(similarity_top)

        return next_puzzle[index_max], 0
# Funkcja zwraca listę z puzzlami z ramki o dokładnym dopasowaniu
def matching_frame(next_possible_puzzle, first_puzzle, binding_value, binding_next_value):
    next_puzzle = []
    if len(next_possible_puzzle) == 0:
        return next_puzzle
    for i in range(len(next_possible_puzzle)):

        vector1 = first_puzzle.iloc[0][binding_value]
        vector2 = next_possible_puzzle.iloc[i][binding_next_value]

        if vector1 == None:
            return next_puzzle
        if vector2 == None:
            break

        if len(vector1) < len(vector2):
            vector1, vector2 = vector2, vector1

        flag = check_if_subset(vector1,
                               vector2)  # Sprawdzamy, czy szerokości wypustki wypukłej są podzbiorem kolejnych elementów dla wypustki wklęsłej

        if flag == True:
            next_puzzle.append(next_possible_puzzle.iloc[i]['id'])

    return next_puzzle

#Wybieranie kolejnego puzzla do ramki - najpierw dokładne dopasowania potem dopasowania dla kształtów
#Jeżeli nie ma takich puzzli wybieramy losowy z pozostałych
#2 zwracana wartość mówi, czy dokładne dopasowanie było tylko dla jednego elementu (1-tak, 0-nie)
def messages_frame(next_puzzle,next_possible_puzzle,first_puzzle,whole_df,binding_value,binding_next_value,final_matrix,remaining_puzzles):
    if(len(next_possible_puzzle)==0):

        return remaining_puzzles[0],-1
    if(len(next_puzzle)==1):
        return next_puzzle[0],1
    elif (len(next_puzzle)==0):

        similarity=get_colors(next_possible_puzzle,first_puzzle,binding_value,binding_next_value)
        index_max=np.argmax(similarity)
        return next_possible_puzzle.iloc[index_max]['id'],0
    else:

        next_puzzle_values=whole_df[whole_df['id'].isin(next_puzzle)]
        similarity=get_colors(next_puzzle_values,first_puzzle,binding_value,binding_next_value)
        index_max=np.argmax(similarity)
        return next_puzzle_values.iloc[index_max]['id'],0

# Funkcja zwraca listę z puzzlami z ramki o dokładnym dopasowaniu
def matching_frame(next_possible_puzzle, first_puzzle, binding_value, binding_next_value):
    next_puzzle = []
    if len(next_possible_puzzle) == 0:
        return next_puzzle
    for i in range(len(next_possible_puzzle)):

        vector1 = first_puzzle.iloc[0][binding_value]
        vector2 = next_possible_puzzle.iloc[i][binding_next_value]

        if vector1 == None:
            return next_puzzle
        if vector2 == None:
            break

        if len(vector1) < len(vector2):
            vector1, vector2 = vector2, vector1

        flag = check_if_subset(vector1,
                               vector2)  # Sprawdzamy, czy szerokości wypustki wypukłej są podzbiorem kolejnych elementów dla wypustki wklęsłej

        if flag == True:
            next_puzzle.append(next_possible_puzzle.iloc[i]['id'])

    return next_puzzle

#Wybieranie kolejnego puzzla do ramki - najpierw dokładne dopasowania potem dopasowania dla kształtów
#Jeżeli nie ma takich puzzli wybieramy losowy z pozostałych
#2 zwracana wartość mówi, czy dokładne dopasowanie było tylko dla jednego elementu (1-tak, 0-nie)
def messages_frame(next_puzzle,next_possible_puzzle,first_puzzle,whole_df,binding_value,binding_next_value,final_matrix,remaining_puzzles):
    if(len(next_possible_puzzle)==0):

        return remaining_puzzles[0],-1
    if(len(next_puzzle)==1):
        return next_puzzle[0],1
    elif (len(next_puzzle)==0):

        similarity=get_colors(next_possible_puzzle,first_puzzle,binding_value,binding_next_value)
        index_max=np.argmax(similarity)
        return next_possible_puzzle.iloc[index_max]['id'],0
    else:

        next_puzzle_values=whole_df[whole_df['id'].isin(next_puzzle)]
        similarity=get_colors(next_puzzle_values,first_puzzle,binding_value,binding_next_value)
        index_max=np.argmax(similarity)
        return next_puzzle_values.iloc[index_max]['id'],0


# Przykładowo wartość `top` oznacza sposób układania górnej ramki
def values_of_binding_columns(side):  # Wartości przy dopasowywaniu poszczególnych stron
    if (side == 'top'):
        binding = '4_x'
        binding_next = '3_x'
        binding_value = '4_y'
        binding_next_value = '3_y'
        condition = '1_x'

    elif (side == 'bottom'):
        binding = '4_x'
        binding_next = '3_x'
        binding_value = '4_y'
        binding_next_value = '3_y'
        condition = '2_x'

    elif (side == 'left'):
        binding = '2_x'
        binding_next = '1_x'
        binding_value = '2_y'
        binding_next_value = '1_y'
        condition = '3_x'

    elif (side == 'right'):
        binding = '2_x'
        binding_next = '1_x'
        binding_value = '2_y'
        binding_next_value = '1_y'
        condition = '4_x'

    return binding, binding_next, binding_value, binding_next_value, condition


# Funkcja wybiera wszystkie puzzle z ramki o odpowiednim kształcie
# Zwraca kolejny puzzel
def solved_puzzle_frame(whole_df, first_puzzle, side, directory, final_matrix):
    path =  directory
    path_el = os.listdir(path)

    binding, binding_next, binding_value, binding_next_value, condition = values_of_binding_columns(side)

    if (first_puzzle.iloc[0][binding] == 'wklesle'):  # Oddzielne warunki na układanie ramki
        next_possible_puzzle = whole_df[(whole_df[condition] == 'ramka') & (whole_df[binding_next] == "wypukle")]
    else:
        next_possible_puzzle = whole_df[(whole_df[condition] == 'ramka') & (whole_df[binding_next] == "wklesle")]

    vector_of_possible_puzzles = if_final_matrix_element2(list(next_possible_puzzle['id']), final_matrix)
    possible_puzzles_without_removed = next_possible_puzzle[next_possible_puzzle['id'].isin(vector_of_possible_puzzles)]

    next_puzzle = matching_frame(possible_puzzles_without_removed, first_puzzle, binding_value, binding_next_value)

    rem_puzzles = []
    if (len(vector_of_possible_puzzles) == 0):
        rem_puzzles = if_final_matrix_element2(list(whole_df[whole_df['type'] == 'frame']['id']), final_matrix)
        print(rem_puzzles)
    return messages_frame(next_puzzle, possible_puzzles_without_removed, first_puzzle, whole_df, binding_value,
                          binding_next_value, final_matrix, rem_puzzles)



def solving_puzzle_frame(whole_df, final_matrix, directory):  # Układamy całą ramkę
    height = len(final_matrix)
    width = len(final_matrix[0])

    sides = ['top', 'bottom', 'left', 'right']
    limit = [width, width, height, height]
    corners = [final_matrix[0][0], final_matrix[-1][0], final_matrix[0][0],
               final_matrix[0][-1]]  # Narożniki, od których będziemy układać

    number_of_accurate_matching = 0
    number_of_iteration = 0

    for i in range(len(sides)):
        flag = True
        first_puzzle = whole_df[(whole_df['id'] == corners[i])]
        for j in range(limit[i] - 1):
            # print(i,j)
            if (flag == False):
                if (i == 0 or i == 1):
                    if (i == 0):
                        x = 0
                    else:
                        x = -1
                    final_matrix[x][j] = rem_puzzles[ind]

                else:
                    if (i == 2):
                        x = 0
                    else:
                        x = -1
                    final_matrix[j][x] = rem_puzzles[ind]
                ind += 1
            else:
                if (i == 0 or i == 1):
                    if (i == 0):
                        x = 0
                    else:
                        x = -1
                    final_matrix[x][j] = first_puzzle.iloc[0]['id']
                else:
                    if (i == 2):
                        x = 0
                    else:
                        x = -1
                    final_matrix[j][x] = first_puzzle.iloc[0]['id']

            if (j < limit[i] - 2):
                next_puzzle_element, is_accurate_matching = solved_puzzle_frame(whole_df, first_puzzle, sides[i],
                                                                                directory, final_matrix)
                number_of_accurate_matching += is_accurate_matching
                if (is_accurate_matching == -1):
                    flag = False
                    rem_puzzles = if_final_matrix_element2(list(whole_df[whole_df['type'] == 'frame']['id']),
                                                           final_matrix)
                    ind = 0
                    continue
                number_of_iteration += 1

                first_puzzle = whole_df[(whole_df['id'] == next_puzzle_element)]

    return final_matrix, round(number_of_accurate_matching / number_of_iteration, 2)


# funkcja mówiąca, które krawędzie mamy łączyć ze sobą przy układaniu środka obrazka i rozpoczynania od różnych narożników
def values_of_binding_columns_non_frame(side):  # Wartości przy dopasowywaniu poszczególnych stron
    if (side == 'left_top'):
        binding_first = '1_x'
        binding_first_next = '2_x'
        binding_second = '4_x'
        binding_second_next = '3_x'

        binding_first_value = '1_y'
        binding_first_next_value = '2_y'
        binding_second_value = '4_y'
        binding_second_next_value = '3_y'

    elif (side == 'right_top'):
        binding_first = '1_x'
        binding_first_next = '2_x'
        binding_second = '3_x'
        binding_second_next = '4_x'

        binding_first_value = '1_y'
        binding_first_next_value = '2_y'
        binding_second_value = '3_y'
        binding_second_next_value = '4_y'

    elif (side == 'left_bottom'):
        binding_first = '2_x'
        binding_first_next = '1_x'
        binding_second = '4_x'
        binding_second_next = '3_x'

        binding_first_value = '2_y'
        binding_first_next_value = '1_y'
        binding_second_value = '4_y'
        binding_second_next_value = '3_y'

    elif (side == 'right_bottom'):
        binding_first = '2_x'
        binding_first_next = '1_x'
        binding_second = '3_x'
        binding_second_next = '4_x'

        binding_first_value = '2_y'
        binding_first_next_value = '1_y'
        binding_second_value = '3_y'
        binding_second_next_value = '4_y'

    return binding_first, binding_first_next, binding_second, binding_second_next, binding_first_value, binding_first_next_value, binding_second_value, binding_second_next_value


#Sposób układania puzzli dla poszczególnych narożników
def get_additional_puzzles(side,width,height):
    if(side=='left_top'):
        first_indices=-1,0
        second_indices=0,-1
        x=range(1,height-1)
        y=range(1,width-1)
    elif(side=='right_top'):
        first_indices=-1,0
        second_indices=0,1
        x=range(1,height-1)
        y=range(width-2,0,-1)
    elif(side=='left_bottom'):
        first_indices=1,0
        second_indices=0,-1
        x=range(height-2,0,-1)
        y=range(1,width-1)
    else:
        first_indices=1,0
        second_indices=0,1
        x=range(height-2,0,-1)
        y=range(width-2,0,-1)

    return first_indices,second_indices,x,y


def solving_whole_image(whole_df, directory, final_matrix, side):  # Tablica z końcowymi pozycjami puzzli
    width = len(final_matrix[0])
    height = len(final_matrix)

    number_of_accurate_matching = 0
    number_of_iteration = 0
    sides = ['left_top', 'right_top', 'left_bottom', 'right_bottom']

    final_matrices = []
    accuracy = []

    first_indices, second_indices, x, y = get_additional_puzzles(side, width, height)
    for i in x:
        for j in y:
            additional_puzzles = [final_matrix[i + second_indices[0]][j + second_indices[1]]]
            first_puzzle = final_matrix[i + first_indices[0]][j + first_indices[1]]

            next_puzzle, is_accurate_matching = solving_puzzle_non_frame(whole_df,
                                                                         whole_df[whole_df['id'] == first_puzzle], side,
                                                                         directory, final_matrix, additional_puzzles)
            number_of_accurate_matching += is_accurate_matching
            number_of_iteration += 1

            final_matrix[i][j] = next_puzzle
    acc_nf = round(number_of_accurate_matching / number_of_iteration, 2)

    return final_matrix, acc_nf
