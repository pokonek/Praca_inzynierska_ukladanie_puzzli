import tkinter as tk
from tkinter import filedialog, ttk
from PIL import  ImageTk

from app2 import start, frame_top, frame_left
from neural_network import visualization_of_next_puzzles, n_best_possible_puzzles
from visu import matrix_of_translation, visualization

#Skrypt zawiera interfejs do części pracy związanej z siecią neuronową
#Po jego wykonaniu użytkownik może zagrać w prostą grę
#Gra polega na układaniu obrazka. Kolejne kawałki sugeruje nam sieć neuronowa

class ImageApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Układanie puzzli - sztuczna inteligencja")
        self.master.configure(bg='pink')

        #Ramka pierwsza służy do wczytania katalogu z elementami
        self.frame1 = tk.Frame(self.master)
        self.frame1.pack(padx=10, pady=10)

        self.directory_path = tk.StringVar()
        directory_entry = tk.Entry(self.frame1, textvariable=self.directory_path, state='readonly', width=40)
        directory_entry.grid(row=0, column=0, padx=10, pady=10)

        # Guzik potweirdzający wybów katalogu
        self.choose_button = tk.Button(self.frame1, text="Wybierz katalog z puzzlami", command=self.choose_directory)
        self.choose_button.grid(row=1, column=0, pady=10)

        # Ramka druga służy do wyświetlania propozycji kolejnych puzzli
        self.frame2 = tk.Frame(self.master,width=600, height=600, bg='pink')
        self.frame2.pack(padx=10, pady=10)

        self.image_label = tk.Label(self.frame2)
        self.image_label.pack()
        self.image_label.configure(bg='pink')

        # Ramka trzecia służy do obsługi wyświetlanych propozycji
        self.frame3 = tk.Frame(self.master)
        self.frame3.pack(padx=10, pady=10)

        #Lista z dostępnymi puzzlami
        self.color_var = tk.StringVar()
        self.color_var.set('Dostępne puzzle: ')  # Default background color
        self.color_options = []
        self.color_dropdown = ttk.Combobox(self.frame3, textvariable=self.color_var, values=self.color_options,
                                           state='readonly')
        self.color_dropdown.grid(row=0, column=1, padx=10, pady=10)
        self.color_dropdown.configure(state='disabled')

        #Guziki potrzebne do obsługi propozycji

        #Wyświetlanie kolejnych 6 puzzli
        self.choose_button2 = tk.Button(self.frame3, text="Następne 6", command=self.display_next)
        self.choose_button2.grid(row=1, column=2, pady=10)
        self.choose_button2.configure(state='disabled')

        #Wyświetlanie poprzednich 6 puzzli
        self.choose_button3 = tk.Button(self.frame3, text="Poprzednie 6", command=self.display_previous)
        self.choose_button3.grid(row=1, column=0, pady=10)
        self.choose_button3.configure(state='disabled')

        #Potwierdzenie wyboru danego puzzla
        self.submit_button = tk.Button(self.frame3, text="Zaakceptuj", command=self.submit)
        self.submit_button.grid(row=1, column=1, pady=5)
        self.submit_button.configure(state='disabled')

    #Wybór katalogu z puzzlami
    def choose_directory(self):
        # Prompt the user to select a directory
        directory_path = filedialog.askdirectory()

        # Update the variable and entry with the chosen directory
        if directory_path:
            self.directory_path.set(directory_path)

            # Display an image from the selected directory
            self.display_image(directory_path)

    #W zależności od etapu układania wywołujemy inny widok
    def visulization_of_best(self):
        if(self.stage=='frame_top'):
            pil_image = visualization_of_next_puzzles(self.whole_df2, self.result[self.n:self.m], self.directory_path.get(),
                                                      self.final_matrix[self.i][self.j], 0,
                                                      self.stage)

        elif(self.stage=='frame_left'):
            pil_image = visualization_of_next_puzzles(self.whole_df2, self.result[self.n:self.m],
                                                      self.directory_path.get(),
                                                       0,self.final_matrix[self.i][self.j],
                                                      self.stage)

        else:

            pil_image = visualization_of_next_puzzles(self.whole_df2, self.result[self.n:self.m], self.directory_path.get(),
                                                      self.final_matrix[self.i][self.j-1], self.final_matrix[self.i-1][self.j])

        # Aktualizacja obrazka
        pil_image=pil_image.resize((3*pil_image.width//4,3*pil_image.height//4))
        tk_image = ImageTk.PhotoImage(pil_image)
        self.image_label.configure(image=tk_image)
        self.image_label.image = tk_image

        #Aktualizacja listy z propozycjami
        self.color_dropdown.configure(state='normal', values=self.result[self.n:self.m])
        self.color_var.set(self.result[self.n])

    #Wyświetlanie poprzedniej serii puzzli
    def display_previous(self):

        #Aktualizujemy wartości indeksów wyświetlanych puzzli
        if(self.m==len(self.result)):

            self.n -=6
            self.m = self.n+6

        else:
            self.n-=6
            self.m-=6

        #Aktualizacja stanu przycisków
        if (self.n == 0):
            self.choose_button3.configure(state='disabled')

        if self.m<len(self.result):
            self.choose_button2.configure(state='normal')

        #Zmiana widoku
        self.visulization_of_best()

    def display_next(self):
        # Aktualizujemy wartości indeksów wyświetlanych puzzli
        if(len(self.result)<self.m+6):

            self.n=self.m
            self.m=len(self.result)

        else:
            self.n+=6
            self.m+=6

        # Aktualizacja stanu przycisków
        if self.m==len(self.result):
            self.choose_button2.configure(state='disabled')

        if self.n>0:
            self.choose_button3.configure(state='normal')
        #Zmiana widoku
        self.visulization_of_best()

    #Potwierdzenie wyboru kolejnego elementu
    def submit(self):
        # Aktualizacja stanu przycisków
        self.choose_button3.configure(state='disabled')
        k=1
        #W zależności od etapu, aktualizujemy macierz z rozwiązaniem
        #Przygotowujemy nowe propozycje elemnetów
        if(self.stage=='frame_top'):
            if(self.j==self.columns-2): #Ostatnia kolumna w pierwszym wierszu; zmiana etapu układania
                self.stage='frame_left'
                self.final_matrix[self.i][self.j+1] = self.color_var.get()
                self.i=0
                self.j=0
                self.result = frame_left(self.final_matrix[self.i][self.j], self.whole_df2,
                                         self.directory_path.get(), self.final_matrix)
            else:   #Przejście do kolejnej kolumny pierwszego wiersza
                self.j += 1
                self.final_matrix[self.i][self.j] = self.color_var.get()
                self.result = frame_top(self.color_var.get(), self.whole_df2, self.directory_path.get(), self.final_matrix)


        elif (self.stage == 'frame_left'):
            if(self.i==self.rows-2):    #Ostatni wiersz w pierwszej kolumnie; zmiana etapu układania
                self.final_matrix[self.i+1][self.j] = self.color_var.get()
                self.stage = 'non_frame'
                self.i = 1
                self.j = 1
                self.result = n_best_possible_puzzles(self.whole_df2, self.directory_path.get(), self.final_matrix,
                                                      self.final_matrix[self.i - 1][self.j],
                                                      self.final_matrix[self.i][self.j-1])
            else:   #Przejście do kolejnego wiersza pierwszej kolumny
                self.i+=1
                self.final_matrix[self.i][self.j] = self.color_var.get()
                self.result = frame_left(self.color_var.get(), self.whole_df2, self.directory_path.get(),
                                         self.final_matrix)

        else:
            if(self.j==self.columns-1 and self.i!=self.rows-1): #Przejście do kolejnego wiersza
                self.final_matrix[self.i][self.j] = self.color_var.get()
                self.j=1
                self.i+=1
                self.result = n_best_possible_puzzles(self.whole_df2, self.directory_path.get(), self.final_matrix,
                                                      self.final_matrix[self.i - 1][self.j],
                                                      self.final_matrix[self.i][self.j - 1])
            elif(self.j==self.columns-1 and self.i==self.rows-1):   #Dołożenie ostatniego elementu
                self.choose_button.configure(state='normal')
                self.choose_button2.configure(state='disabled')
                self.choose_button3.configure(state='disabled')
                self.submit_button.configure(state='disabled')
                self.color_dropdown.configure(state='disabled')

                self.final_matrix[self.i][self.j] = self.color_var.get()

                #Wyświetlenie końcowej wizualizacji
                matrix = matrix_of_translation(self.final_matrix, self.whole_df2, self.directory_path.get())
                pil_image2 = visualization(self.final_matrix, matrix, self.whole_df2, self.directory_path.get())

                pil_image2.thumbnail((500, 500))
                tk_image2 = ImageTk.PhotoImage(pil_image2)

                self.image_label.configure(image=tk_image2)
                self.image_label.image = tk_image2
                k=0

            else:
                self.final_matrix[self.i][self.j] = self.color_var.get()
                self.j+=1
                self.result = n_best_possible_puzzles(self.whole_df2, self.directory_path.get(), self.final_matrix,
                                                      self.final_matrix[self.i - 1][self.j],
                                                      self.color_var.get())

        self.n=0
        if(len(self.result)<6):
            self.choose_button2.configure(state='disabled')
            self.m=len(self.result)
        else:
            self.m=6
        if(k!=0):
            self.visulization_of_best()

    #Funkcja do rozpoczęcia układania
    def display_image(self, directory_path):
        self.choose_button.configure(state='disabled')
        self.choose_button2.configure(state='normal')
        self.submit_button.configure(state='normal')
        #Wyznaczamy metryki dla elementów obrazka
        #Ustalenie początkowych wartości
        self.final_matrix, self.whole_df2, self.result, self.columns, self.rows = start(directory_path)
        self.n, self.m, self.i, self.j,self.stage = 0, 6, 0, 0, 'frame_top'
        self.visulization_of_best()

def main():
    root = tk.Tk()
    app = ImageApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()