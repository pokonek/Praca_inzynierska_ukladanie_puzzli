import time
import tkinter as tk
from tkinter import filedialog, font
from PIL import  ImageTk
from main import demonstrator_without_rotations
from visu import matrix_of_translation, visualization

#Skrypt służący do wyświetlenia interfejsu do częsci pracy związanej z metodą manualną
#Na wejściu podajemy katalog z puzzlami
#Jako wynik otrzymujemy ułożony obrazek oraz statystyki układania puzzli
class ImageApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Układanie puzzli - metoda manualna")
        self.master.configure(bg='pink')
        # Ramka pierwsza służy do podania folderu z puzzlami
        self.frame1 = tk.Frame(self.master)
        self.frame1.pack(padx=10, pady=10)

        self.directory_path = tk.StringVar()
        directory_entry = tk.Entry(self.frame1, textvariable=self.directory_path, state='readonly', width=40)
        directory_entry.grid(row=0, column=0, padx=10, pady=10)

        # Guzik do potwierdzenia wyboru folderu
        choose_button = tk.Button(self.frame1, text="Choose Directory", command=self.choose_directory)
        choose_button.grid(row=1, column=0, pady=10)

        # Ramka druga służy do wyświetlenia końcowej wizualizacji
        self.frame2 = tk.Frame(self.master)
        self.frame2.pack(padx=10, pady=10)
        self.image_label = tk.Label(self.frame2)
        self.image_label.pack()
        self.image_label.configure(bg='pink')

        # Ramka trzecia służy do wyświetlenia statystyk
        self.frame3 = tk.Frame(self.master)
        self.frame3.pack(padx=10, pady=10)

        self.stats_label = tk.Label(self.frame3)
        self.stats_label.pack()
        self.stats_label.configure(bg='pink')

        text_font = font.Font(family='Helvetica', size=28)  # Adjust the size as needed
        self.stats_label.config(font=text_font)

    #Wybór katalogu z puzzlami
    def choose_directory(self):
        # Prompt the user to select a directory
        directory_path = filedialog.askdirectory()

        # Update the variable and entry with the chosen directory
        if directory_path:
            self.directory_path.set(directory_path)

            # Display an image from the selected directory
            self.display_image(directory_path)

    def display_image(self, directory_path):

        start_time = time.time()
        #Wywołanie metody manualnej dla podanego folderu
        final_result, whole_df2, acc_nf = demonstrator_without_rotations(directory_path)
        matrix = matrix_of_translation(final_result, whole_df2, directory_path)
        pil_image = visualization(final_result, matrix, whole_df2, directory_path)
        end_time = time.time()
        #Statystyki dotyczące danej symulacji
        stats = f'Liczba puzzli: {len(final_result) * len(final_result[0])}\n' \
                f'Współczynnik dokładnych dopasowań: {acc_nf}\n' \
                f'Czas wykonania: {round(end_time - start_time, 1)} sekund'


        pil_image.thumbnail((500, 500))
        tk_image = ImageTk.PhotoImage(pil_image)

        # Ustawienie końcowej wizualizacji
        self.image_label.configure(image=tk_image)
        self.image_label.image = tk_image
        #Ustawienie statystyk
        self.stats_label.configure(text=stats)


def main():
    root = tk.Tk()
    app = ImageApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()