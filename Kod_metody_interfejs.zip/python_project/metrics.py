from PIL import Image
import os
import pandas as pd
import math


#Funkcja do zamiany fragmentu puzzla na macierz pixeli
def getPixels(filename):
    img = Image.open(filename, 'r')
    if(img.mode!='RGBA'):
        img=img.convert('RGBA')  #Wszystkie zdjęcia opisane w formacie RGBA
    w, h = img.size
    pix = list(img.getdata())
    return [pix[n:n+w] for n in range(0, w*h, w)]


# Funkcja sprawdzająca, czy dany kawałek należy do ramki
def is_puzzle_frame(image):
    df = pd.DataFrame(image).T
    image_transpose = df.values.tolist()  # Przydatne do badania pixeli w kolumnach

    first_row = image[0]
    second_row = image[1]  # Sprawdzamy też drugi wiersz/kolumnę ze względu na strukturę niektórych puzzli z ramki
    last_row = image[-1]
    second_to_last_row = image[-2]
    first_column = image_transpose[0]
    second_column = image_transpose[1]
    last_column = image_transpose[-1]
    second_to_last_column = image_transpose[-2]

    frame = [first_row, second_row, second_to_last_row, last_row, first_column, second_column, second_to_last_column,
             last_column]
    frame_elements = []
    for f in frame:
        flag = False
        number_of_pixels_in_row = 0  # Liczba kolorowych pixeli z rzędu w jednym z wierszy; elementy ramki cechują się dużą liczbą
        for i in range(len(f)):
            if f[i] != (0, 0, 0, 0) and flag == False:
                flag = True
                number_of_pixels_in_row += 1

            elif f[i] != (0, 0, 0, 0) and flag == True:
                number_of_pixels_in_row += 1
            elif f[i] == (0, 0, 0, 0) and flag == True:
                flag = False
                frame_elements.append(number_of_pixels_in_row)
                break
        if flag == True:
            frame_elements.append(number_of_pixels_in_row)

    return frame_elements


def elements_of_frame_without_corners(elements,
                                      corners):  # Funkcja do oddzielenia narożników od pozostałych elementów ramki

    for corner in corners:
        for i in range(len(elements)):
            if corner in elements[i]:
                elements[i].remove(corner)

    return elements


def puzzles_without_frame_elements(frame, corners, directory):  # Funkcja do znalezienia elementów spoza ramki
    whole_frame = []

    path = directory
    path_el = os.listdir(path)  # Założenie, że katalog z puzzlami znajduje się w obecnym folderze
    puzzles_without_frame = []
    for i in range(len(frame)):
        for j in range(len(frame[i])):
            whole_frame.append(frame[i][j])
    for i in range(len(corners)):
        whole_frame.append(corners[i])

    for i in range(len(path_el)):
        if (path_el[i] in whole_frame):
            continue
        else:
            puzzles_without_frame.append(path_el[i])

    return puzzles_without_frame


def find_frame_elements(directory):  # Wykorzystanie wszystkich poprzednich funkcji do podzielenia elemntów
    path =  directory
    path_el = os.listdir(path)
    frame_elements = [[] for i in range(4)]
    corners = [0, 0, 0, 0]
    index = [-1, -1, -1, -1]
    for file in path_el:
        sum_of_pixels = [0, 0, 0, 0]
        file_path = path + "\\" + file
        image = getPixels(file_path)
        height = len(image)
        width = len(image[0])
        pixels_in_row = is_puzzle_frame(image)
        ##  WAŻNE
        ### Od tego miejsca przyjmuję konwencję:
        #### index 0 - górna ramka obrazka lub górna część puzzla
        #### index 1 - dolna ramka obrazka lub dolna część puzzla
        #### index 2 - lewa ramka obrazka lub lewa część puzzla
        #### index 3 - prawa ramka obrazka lub prawa część puzzla
        ##
        if (pixels_in_row[0] > 0.5 * width or pixels_in_row[
            1] > 0.5 * width):  # Założenie, że puzzle z ramki mają liczbę pixeli z rzędu>50% wymiaru
            frame_elements[0].append(file)  # Sprawdza się na razie zawsze
        elif (pixels_in_row[2] > 0.5 * width) or pixels_in_row[3] > 0.5 * width:
            frame_elements[1].append(file)
        elif (pixels_in_row[4] > 0.5 * height or pixels_in_row[5] > 0.5 * height):
            frame_elements[2].append(file)
        elif (pixels_in_row[6] > 0.5 * height or pixels_in_row[7] > 0.5 * height):
            frame_elements[3].append(file)

        sum_of_pixels[0] = max(pixels_in_row[0], pixels_in_row[1]) + max(pixels_in_row[4], pixels_in_row[
            5])  # Szukam, które elementy są narożnikami
        sum_of_pixels[1] = max(pixels_in_row[0], pixels_in_row[1]) + max(pixels_in_row[6], pixels_in_row[
            7])  # Liczy się suma pixeli na 2 sąsiadujących krawędziach
        sum_of_pixels[2] = max(pixels_in_row[2], pixels_in_row[3]) + max(pixels_in_row[4], pixels_in_row[5])
        sum_of_pixels[3] = max(pixels_in_row[2], pixels_in_row[3]) + max(pixels_in_row[6], pixels_in_row[7])

        for i in range(len(sum_of_pixels)):
            if sum_of_pixels[i] > corners[i]:
                corners[i] = sum_of_pixels[i]
                index[i] = file

    frame_elements = elements_of_frame_without_corners(frame_elements, index)
    non_frame_elements = puzzles_without_frame_elements(frame_elements, index, directory)

    return frame_elements, index, non_frame_elements  # Ostateczny podział na 3 tablice


#Funkcja zwraca n pierwszych szerokości dla danej wypustki wypukłej
def metrics_for_wypukle(image,side,n):
    vector=[]

    if(side=="top"):
        x=range(n)
    elif(side=="bottom"):
        x=range(len(image)-1,len(image)-(n+1),-1)
    elif(side=="left"):
        df=pd.DataFrame(image).T
        image=df.values.tolist()
        x=range(n)

    elif(side=="right"):
        df=pd.DataFrame(image).T
        image=df.values.tolist()
        x=range(len(image)-1,len(image)-(n+1),-1)

    for i in x:
        start=-1
        stop=-1
        for j in range(len(image[i])):
            if image[i][j]!=(0,0,0,0) and start==-1:            #Sprawdzamy, gdzie zaczynają się pixele kolorowe
                start=j
            elif image[i][j]==(0,0,0,0) and start>-1:           #Oraz gdzie się kończą
                stop=j
                vector.append(stop-start)
                break
    return vector


def metrics_for_wklesle(image, side):
    vector = []

    if (side == "top"):
        x = range(len(image) // 2)  # Liczę do połowy, bo wypustka nigdy nie będzie większa

    elif (side == "bottom"):
        x = range(len(image) - 1, len(image) // 2, -1)

    elif (side == "left"):
        df = pd.DataFrame(image).T
        image = df.values.tolist()
        x = range(len(image) // 2)

    elif (side == "right"):
        df = pd.DataFrame(image).T
        image = df.values.tolist()
        x = range(len(image) - 1, len(image) // 2, -1)

    for i in x:
        start = -1
        stop = -1
        flag = 0
        middle_index = []  # Liczba kolorowych pasów w jednym rzędzie
        possible_next = []
        for j in range(len(image[i])):  # Podobnie jak przy sprawdzaniu rodzaju wypustki
            if image[i][j] != (
            0, 0, 0, 0) and start == -1:  # Szukamy liczby pustych pixeli w rzędzie pomiędzy dwoma kolorowymi częściami
                start = j
            elif image[i][j] == (0, 0, 0, 0) and start > -1 and stop == -1:
                stop = j
            elif image[i][j] != (0, 0, 0, 0) and stop > -1 and flag == 0:
                possible_next.append(j - stop)
                flag = +1

                half_of_size = len(image) / 2
                middle_point = (j + stop) / 2
                middle_index.append(abs(half_of_size - middle_point))

            elif flag != 0 and image[i][j] == (0, 0, 0, 0):
                stop = j
                flag = 0

        if (len(middle_index) == 2):  # Szukam pustego pasa, który znajduje się najbliżej środka wymiaru
            min_index = middle_index.index(min(middle_index))
            possible_next[0] = possible_next[min_index]

        if (len(possible_next) > 0):
            vector.append(possible_next[0])
        else:
            vector.append(0)

    return vector

def metrics_of_bindings(final_matrix,directory,n):                  #Funkcja zwraca tablicę z policzonymi metrykami
    matrix_of_metrics=[ [False]*5 for i in range(len(final_matrix))]
    path = directory
    sides=['top','bottom','left','right']
    for i in range(len(matrix_of_metrics)):
        for j in range(1,5):
            image=getPixels(path+"//"+final_matrix[i][0])
            matrix_of_metrics[i][0]=final_matrix[i][0]
            if(final_matrix[i][j]=="wypukle"):
                matrix_of_metrics[i][j]=metrics_for_wypukle(image,sides[j-1],n)
            elif(final_matrix[i][j]=="wklesle"):
                matrix_of_metrics[i][j]=metrics_for_wklesle(image,sides[j-1])
            else:
                matrix_of_metrics[i][j]=None

    return matrix_of_metrics


# Funkcja zwraca maksymalną głębokość danej wypustki oraz współrzędne, gdzie znajduje się to miejsce
def metrics_binding_max_depth(image, whole_df2, directory):
    data = getPixels(directory + '//' + image)

    start = math.floor(0.35 * len(
        data[0]))  # Odcinamy po 35 % z lewej i prawej strony obrazka; max głębokość musi być w pobliżu środka wymiaru
    stop = math.floor(0.65 * len(data[0]))
    width = range(start, stop)

    start2 = math.floor(0.35 * len(data))
    stop2 = math.floor(0.65 * len(data))
    width2 = range(start2, stop2)

    puzzle = whole_df2[whole_df2[0] == image]
    columns = ['1_x', '2_x', '3_x', '4_x']
    result = [0] * 4
    result_ind = [0] * 4
    it = 0
    for column in columns:

        if (puzzle.iloc[0][column] == "wklesle"):  # Głębokość tylko dla wklęsłych, dla wypukłych 0

            if (column == '1_x'):
                x = width
                y = range(len(data) // 2)

            if (column == '2_x'):
                x = width
                y = range(len(data) - 1, len(data) // 2, -1)

            if (column == '3_x'):
                x = width2
                y = range(len(data[0]) // 2)

            if (column == '4_x'):
                x = width2
                y = range(len(data[0]) - 1, len(data[0]) // 2, -1)
        else:
            it += 1
            continue
        vector = []
        indices = []
        for i in x:
            k = 0
            for j in y:
                if (column == '1_x' or column == '2_x'):
                    if (data[j][i] == (0, 0, 0, 0)):
                        k = k + 1
                    elif (data[j][i] != (0, 0, 0, 0) and k > 0):

                        break

                else:
                    if (data[i][j] == (0, 0, 0, 0)):
                        k = k + 1
                    elif (data[i][j] != (0, 0, 0, 0) and k > 0):

                        break

            if (column == '1_x' or column == '2_x'):
                indices.append([j, i])
            else:
                indices.append([i, j])
            vector.append(k)
        result[it] = max(vector)
        index_of_max_depth = vector.index(max(vector))
        result_ind[it] = indices[index_of_max_depth]

        it = it + 1

    return result, result_ind

#Funkcja zwraca kolory wypustek dla wszystkich puzzli
def colors_of_pixels(directory,whole_df2):
    path = directory
    path_el=os.listdir(path)
    result=[]
    result2=[]
    for file in path_el:
        data=getPixels(path+'//'+file)
        max_depth,index_of_max_depth=metrics_binding_max_depth(file,whole_df2,directory)
        colors=[]
        for j in range(4):
            current_img=whole_df2[whole_df2[0]==file]
            if(current_img.iloc[0][f'{j+1}_x']=='ramka'):   #Dla ramki nie liczymy kolorów
                colors.append([None])
                continue
            if(j<2):    #Góra, dół
                colors.append([top_bottom_colors(max_depth,index_of_max_depth,data,j)])

            else:       #Lewo, prawo
                colors.append([left_right_colors(max_depth,index_of_max_depth,data,j)])

        result.append(colors)
        result2.append([*max_depth])
    return colors_arrays_to_one_df(result,result2,path_el,whole_df2)

#Całość zapisujemy do ramki danch i łączymy to z poprzednią ramką dotyczącą metryk
def colors_arrays_to_one_df(result,result2,path_el,whole_df2):
    result=pd.DataFrame(result)
    result2=pd.DataFrame(result2)
    path_el=pd.DataFrame(path_el)
    result=pd.concat([path_el,result,result2],axis=1)
    result.columns=[0,'1_c','2_c','3_c','4_c','1_d','2_d','3_d','4_d']
    result=whole_df2.merge(result,right_on=0,left_on=0)
    result['rotation']=0
    return result



#Funkcja zwraca kolor wypustki wypukłej
def colors_wypukle(data,i):
    colors=[]
    if(i==0 or i==1):
        for j in range(len(data[0])):
            if(i==0):
                x=0
            else:
                x=-1
            if data[x][j]!=(0,0,0,0):
                colors.append(data[x][j])
    else:
        for j in range(len(data)):
            if(i==2):
                y=0
            else:
                y=-1
            if data[j][y]!=(0,0,0,0):
                colors.append(data[j][y])

    return colors


# Funkcja znajdująca kolor wypustki wklęsłej znajdującej się na górze lub dole puzzla.
def top_bottom_colors(max_depth, index_of_max_depth, data, i):
    colors = []

    if max_depth[i] != 0:

        x = index_of_max_depth[i][0]

        y = index_of_max_depth[i][1]
        y_2 = index_of_max_depth[i][1] - 1
        flag_y = True
        flag_y_2 = True

        while (flag_y or flag_y_2):
            if (i == 1 and data[x + 1][y] == (0, 0, 0, 0) and data[x][y] != (0, 0, 0, 0)):
                colors.append(data[x][y])
                y = y + 1

            elif (i == 0 and data[x - 1][y] == (0, 0, 0, 0) and data[x][y] != (0, 0, 0, 0)):
                colors.append(data[x][y])
                y = y + 1

            else:
                flag_y = False

            if (i == 1 and data[x][y_2] != (0, 0, 0, 0) and data[x - 1][y_2] == (0, 0, 0, 0)):
                colors.insert(0, data[x][y_2])
                y_2 = y_2 - 1

            if (i == 0 and data[x][y_2] != (0, 0, 0, 0) and data[x - 1][y_2] == (0, 0, 0, 0)):
                colors.insert(0, data[x][y_2])
                y_2 = y_2 - 1

            else:
                flag_y_2 = False


    else:
        return colors_wypukle(data, i)
    return colors


# Funkcja znajdująca kolor wypustki wklęsłej znajdującej się z lewej lub prawej strony puzzla.
def left_right_colors(max_depth, index_of_max_depth, data, i):
    colors = []

    if max_depth[i] != 0:

        x = index_of_max_depth[i][0]

        y = index_of_max_depth[i][1]
        x_2 = index_of_max_depth[i][0] - 1
        flag_x = True
        flag_x_2 = True

        while (flag_x or flag_x_2):
            if (i == 3 and data[x][y + 1] == (0, 0, 0, 0) and data[x][y] != (0, 0, 0, 0)):
                colors.append(data[x][y])
                x = x + 1

            elif (i == 2 and data[x][y - 1] == (0, 0, 0, 0) and data[x][y] != (0, 0, 0, 0)):
                colors.append(data[x][y])
                x = x + 1

            else:
                flag_x = False

            if (i == 3 and data[x_2][y] != (0, 0, 0, 0) and data[x_2][y + 1] == (0, 0, 0, 0)):
                colors.insert(0, data[x_2][y])
                x_2 = x_2 - 1

            elif (i == 2 and data[x_2][y] != (0, 0, 0, 0) and data[x_2][y - 1] == (0, 0, 0, 0)):
                colors.insert(0, data[x_2][y])
                x_2 = x_2 - 1

            else:
                flag_x_2 = False

    else:
        return colors_wypukle(data, i)

    return colors


