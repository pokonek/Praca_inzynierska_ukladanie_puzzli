import numpy as np

from creating_df import create_matrix_of_bindings_type, final_matrix_of_bindings_kind, transform_arrays_to_df, \
    create_whole_df_with_rotations
from metrics import metrics_of_bindings, colors_of_pixels
from neural_network import prepare_color_columns, create_final_matrix_nn, simulation_rate, all_changes_left, \
 simulation_rate_top, all_changes_top


def start(directory):

    type_boolean = create_matrix_of_bindings_type(directory)
    type_string, types_of_elements = final_matrix_of_bindings_kind(type_boolean, directory)
    metrics2 = metrics_of_bindings(type_string, directory, 10)

    whole_df2 = transform_arrays_to_df(type_string, metrics2, types_of_elements)
    whole_df2 = colors_of_pixels(directory, whole_df2)
    whole_df2 = create_whole_df_with_rotations(whole_df2)
    whole_df2 = prepare_color_columns(whole_df2)
    columns, rows = create_final_matrix_nn(whole_df2)

    final_matrix = [[0] * columns for i in range(rows)]

    id = whole_df2.iloc[0]['id']
    final_matrix[0][0] = id

    zz = simulation_rate(whole_df2, id, directory, final_matrix)
    zz = zz[zz['type_right'] != 2]
    t_left, final_left = all_changes_left(whole_df2, directory, final_matrix, id, zz)

    x = np.argsort(-t_left, axis=0)

    resultt = []
    for i in range(len(final_left)):
        resultt.append(final_left.iloc[x[i][0]]['id_right'])


    return  final_matrix,whole_df2, resultt,columns, rows


def frame_top(id,whole_df2,directory,final_matrix):
    zz = simulation_rate(whole_df2, id, directory, final_matrix)
    zz=zz[zz['type_right']!=2]
    t_left, final_left = all_changes_left(whole_df2, directory, final_matrix, id, zz)

    x = np.argsort(-t_left, axis=0)

    resultt = []
    for i in range(len(final_left)):
        resultt.append(final_left.iloc[x[i][0]]['id_right'])

    if (len(resultt) < 10):
        a = len(resultt)
    else:
        a = 10

    return resultt

def frame_left(id,whole_df2,directory,final_matrix):

    zz = simulation_rate_top(whole_df2, id, directory, final_matrix)
    zz = zz[zz['type_bottom'] != 2]
    t_top, final_top = all_changes_top(whole_df2, directory, final_matrix, id, zz)

    x = np.argsort(-t_top, axis=0)

    resultt = []
    for i in range(len(final_top)):
        resultt.append(final_top.iloc[x[i][0]]['id_bottom'])

    return  resultt



